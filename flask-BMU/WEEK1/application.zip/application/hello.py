from flask import Flask,render_template
app = Flask(__name__)

@app.route('/<user>')
def hello_name(user):
	# custom_name='simarjot'
	# return render_template('hello.html', name = 'simar')
	return render_template('hello.html', name = user)

if __name__ == '__main__':
   app.run(debug = True)